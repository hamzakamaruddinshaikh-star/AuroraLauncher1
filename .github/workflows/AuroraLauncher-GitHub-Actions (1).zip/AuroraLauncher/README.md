# Aurora Launcher — GitHub Actions build

This project can build an APK on GitHub without installing Android Studio locally.

## Build the APK on GitHub

1. Sign in to GitHub and create a **new repository**. A name such as `AuroraLauncher` is fine. For easiest setup, choose **Public** or **Private** and do not initialize it with a README.
2. Download and extract this ZIP on your computer.
3. Open the new repository on GitHub, choose **Add file → Upload files**, and upload the *contents* of this `AuroraLauncher` folder (not the outer folder itself). Make sure `.github/workflows/build-apk.yml` is included. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab. If prompted, enable Actions.
5. Select **Build Aurora Launcher APK** on the left, click **Run workflow**, choose `main`, then click **Run workflow** again. A push to `main` also starts a build automatically.
6. Wait for the workflow to finish with a green check. Open that workflow run and find **Artifacts** near the bottom. Download `AuroraLauncher-debug-apk` and extract the downloaded artifact ZIP. It contains `app-debug.apk`.
7. Transfer `app-debug.apk` to your Android phone and install it. Android may ask you to allow installation from the app you used to open the file.

## Notes

- This workflow produces a **debug APK** for testing, not a Play Store release build.
- Keep the repository free of passwords, signing keys, and other secrets.
- The project is a starter launcher. Some of the more advanced concept features (such as GPU particle systems, custom live wallpapers, and advanced glass blur) are not implemented yet.
- If the workflow fails, open the failed run, expand the red step, and share the error text so the build can be fixed.
