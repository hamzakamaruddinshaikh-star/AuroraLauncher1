package com.aurora.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 12, 28)
    private val cyan = Color.rgb(117, 231, 255)
    private val white = Color.rgb(245, 248, 255)
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private var downX = 0f
    private var downY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildHome()
    }

    private fun buildHome() {
        root = FrameLayout(this).apply {
            setBackgroundColor(bg)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(8, 14, 36), Color.rgb(25, 20, 57), Color.rgb(7, 12, 28)))
        }
        val glow = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0x553C7CFF, 0x223B1C8C, 0x0033CCFF.toInt())).apply {
                cornerRadius = dp(280).toFloat()
            }
        }
        val glowParams = FrameLayout.LayoutParams(dp(330), dp(330), Gravity.TOP or Gravity.END)
        glowParams.topMargin = dp(70); glowParams.rightMargin = dp(-130)
        root.addView(glow, glowParams)

        val scroll = ScrollView(this).apply { clipToPadding = false; isFillViewport = true }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(28))
        }
        scroll.addView(content)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        val top = row()
        top.addView(label("A U R O R A", 14, cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(pill("ULTIMATE", "#263E7A"))
        content.addView(top)
        content.addView(space(24))

        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val date = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
        content.addView(label(time, 62, white, false))
        content.addView(label(date, 15, 0xFFB8C7E8.toInt(), false))
        content.addView(space(22))

        val weather = glassCard()
        val weatherRow = row()
        weatherRow.addView(label("☼", 34, 0xFFFFD78C.toInt(), true))
        val weatherText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        weatherText.addView(label("YOUR WORLD, IN MOTION", 12, cyan, true))
        weatherText.addView(label("A beautiful day to explore", 15, white, false))
        weatherRow.addView(weatherText, LinearLayout.LayoutParams(0, -2, 1f))
        weather.addView(weatherRow)
        content.addView(weather, matchWrap())
        content.addView(space(14))

        val music = glassCard()
        val musicRow = row()
        musicRow.addView(label("◉", 30, 0xFFD6B8FF.toInt(), true))
        val musicText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        musicText.addView(label("NOW PLAYING", 11, cyan, true))
        musicText.addView(label("Let the night unfold", 16, white, true))
        musicText.addView(label("Tap to open your music app", 12, 0xFFB5C0DE.toInt(), false))
        musicRow.addView(musicText, LinearLayout.LayoutParams(0, -2, 1f))
        musicRow.addView(label("▶", 22, white, true))
        music.addView(musicRow)
        music.setOnClickListener { launchFirst(listOf("music", "spotify", "youtube music")) }
        content.addView(music, matchWrap())
        content.addView(space(24))

        val appHeader = row()
        appHeader.addView(label("YOUR APPS", 13, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        appHeader.addView(label("Swipe up for all  →", 12, cyan, false))
        content.addView(appHeader)
        content.addView(space(12))

        val favorites = listOf("Phone", "Messages", "Camera", "Photos", "Chrome", "Settings")
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        favorites.chunked(3).forEach { group ->
            val line = row()
            group.forEach { name ->
                val item = appTile(name)
                line.addView(item, LinearLayout.LayoutParams(0, dp(92), 1f))
            }
            while (line.childCount < 3) line.addView(View(this), LinearLayout.LayoutParams(0, dp(92), 1f))
            grid.addView(line)
        }
        content.addView(grid)
        content.addView(space(12))

        val drawerButton = TextView(this).apply {
            text = "✦     OPEN APP UNIVERSE     ✦"
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(white)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = glassBackground(true)
            setPadding(dp(16), dp(17), dp(16), dp(17))
            setOnClickListener { showDrawer() }
        }
        content.addView(drawerButton, matchWrap())
        content.addView(space(12))
        content.addView(label("LIQUID GLASS  •  COSMIC LIGHT  •  FLUID MOTION", 9, 0xFF899BC5.toInt(), true).apply { gravity = Gravity.CENTER })

        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX; val dy = event.y - downY
                    if (dy < -dp(70) && abs(dy) > abs(dx)) showDrawer()
                    true
                }
                else -> true
            }
        }
        animateIn(content)
    }

    private fun showDrawer() {
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(12, 18, 42), Color.rgb(31, 22, 65), Color.rgb(8, 13, 30))).apply { cornerRadius = dp(28).toFloat() }
        }
        val header = row()
        header.addView(label("APP UNIVERSE", 18, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        val close = TextView(this).apply { text = "✕"; textSize = 20f; setTextColor(cyan); setOnClickListener { root.removeView(overlay) } }
        header.addView(close)
        overlay.addView(header)
        overlay.addView(space(12))
        val search = EditText(this).apply {
            hint = "Search your apps…"; setHintTextColor(0xFF8E9CBD.toInt()); setTextColor(white)
            textSize = 15f; singleLine = true; background = glassBackground(false)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        overlay.addView(search, matchWrap())
        overlay.addView(space(14))
        val appScroll = ScrollView(this)
        val appList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        appScroll.addView(appList)
        overlay.addView(appScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val apps = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }.sortedBy { it.first.lowercase(Locale.getDefault()) }
        fun populate(filter: String) {
            appList.removeAllViews()
            apps.filter { it.first.contains(filter, true) }.forEach { (name, pkg) ->
                val appRow = row().apply {
                    setPadding(dp(10), dp(11), dp(10), dp(11))
                    addView(label("◈", 22, cyan, true))
                    val text = label(name, 15, white, false).apply { setPadding(dp(14), 0, 0, 0) }
                    addView(text, LinearLayout.LayoutParams(0, -2, 1f))
                    addView(label("↗", 16, 0xFFB9C9ED.toInt(), true))
                    setOnClickListener { openPackage(pkg) }
                }
                appList.addView(appRow)
                appList.addView(divider())
            }
        }
        populate("")
        search.addTextChangedListener(SimpleTextWatcher { populate(it) })
        overlay.alpha = 0f
        val params = FrameLayout.LayoutParams(-1, -1).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) }
        root.addView(overlay, params)
        overlay.animate().alpha(1f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun appTile(name: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(6), dp(4), dp(6)) }
        val icon = TextView(this).apply {
            text = when (name) { "Phone" -> "☎"; "Messages" -> "▰"; "Camera" -> "◉"; "Photos" -> "✿"; "Chrome" -> "◌"; else -> "⚙" }
            gravity = Gravity.CENTER; textSize = 24f; setTextColor(white); background = glassBackground(true)
        }
        box.addView(icon, LinearLayout.LayoutParams(dp(52), dp(52)))
        box.addView(label(name, 11, 0xFFDCE5FF.toInt(), false).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) })
        box.setOnClickListener { launchFirst(listOf(name.lowercase(Locale.getDefault()))) }
        return box
    }

    private fun launchFirst(keywords: List<String>) {
        val list = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val match = list.firstOrNull { info -> keywords.any { info.loadLabel(packageManager).toString().contains(it, true) } }
        if (match != null) openPackage(match.activityInfo.packageName) else showToast("App not found — open App Universe")
    }

    private fun openPackage(pkg: String) { packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } ?: showToast("This app cannot be opened") }
    private fun showToast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun glassCard(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = glassBackground(false) }
    private fun glassBackground(bright: Boolean): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR,
        if (bright) intArrayOf(0x553C73B8, 0x333A3978, 0x2223A9D2) else intArrayOf(0x442E4A78, 0x332B285C, 0x2222A5C9)).apply {
        cornerRadius = dp(22).toFloat(); setStroke(dp(1), if (bright) 0x887CEBFF.toInt() else 0x5578CFEF)
    }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun pill(text: String, color: String) = TextView(this).apply {
        this.text = text; textSize = 10f; setTextColor(cyan); gravity = Gravity.CENTER; setPadding(dp(12), dp(7), dp(12), dp(7))
        background = GradientDrawable().apply { setColor(Color.parseColor(color)); cornerRadius = dp(18).toFloat(); setStroke(dp(1), 0x6679E7FF) }
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun divider() = View(this).apply { setBackgroundColor(0x223F9BD1); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun animateIn(view: View) { view.alpha = 0f; view.translationY = dp(18).toFloat(); view.animate().alpha(1f).translationY(0f).setDuration(550).setInterpolator(DecelerateInterpolator()).start() }

    override fun onBackPressed() {
        val overlay = if (::root.isInitialized && root.childCount > 1) root.getChildAt(root.childCount - 1) else null
        if (overlay is LinearLayout && overlay.orientation == LinearLayout.VERTICAL && overlay.childCount > 1) root.removeView(overlay)
        else super.onBackPressed()
    }
}

private class SimpleTextWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
