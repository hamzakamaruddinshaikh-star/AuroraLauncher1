plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aurora.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aurora.launcher"
        minSdk = 23
        targetSdk = 30
        versionCode = 1
        versionName = "1.0"
    }
}
